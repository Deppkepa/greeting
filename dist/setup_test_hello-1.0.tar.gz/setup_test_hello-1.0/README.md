https://github.com/Deppkepa/greeting/tree/PyPI

# greeting
В проекте представлена функция, которая здоровается с пользователем.
# Установка
`pip install -e git+https://github.com/Deppkepa/greeting.git`

или

`git clone https://github.com/Deppkepa/greeting.git`

`cd greeting`

`sudo python3 setup.py install`
